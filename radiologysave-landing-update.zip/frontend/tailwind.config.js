/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // ── RadiologySave brand tokens (HANDOFF.md §3) ──
        brand: {
          blue:      '#155EAB',  // tiles, primary buttons, links
          blueDark:  '#114E8F',  // primary hover
          green:     '#1E9E62',  // bore tile, "Save", action/savings accents
          greenDark: '#188551',  // green hover
          ink:       '#1C2B3A',  // headlines, wordmark
          body:      '#52606D',  // body text
          mist:      '#F2F7FC',  // hero background tint (blue)
          mint:      '#EEF8F3',  // eyebrow/pill background (green)
        },
        // ── Legacy ClearScan tokens (kept for existing pages) ──
        navy: { DEFAULT: '#0B1F3A', 50: '#EBF0F7', 100: '#C3D1E6', 500: '#1E4D8C', 700: '#0D2840', 900: '#060F1C' },
        teal: { DEFAULT: '#0D9E75', 50: '#E1F5EE', 100: '#9FE1CB', 400: '#1ABC96', 500: '#0D9E75', 700: '#0b8963' },
        gold: '#F0A500',
      },
      fontFamily: {
        // Inter for the RadiologySave brand (HANDOFF.md §3)
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
        display: ['"DM Serif Display"', 'serif'], // legacy ClearScan pages
      },
      boxShadow: {
        // soft, blue-tinted (HANDOFF.md §3)
        brand: '0 8px 28px rgba(21,94,171,.09)',
      },
      letterSpacing: {
        headline: '-0.025em',
      },
    },
  },
  plugins: [],
};
